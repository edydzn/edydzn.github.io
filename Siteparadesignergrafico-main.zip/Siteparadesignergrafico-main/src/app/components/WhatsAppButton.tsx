import { MessageCircle } from 'lucide-react';

export function WhatsAppButton() {
  const phoneNumber = '5575936184057'; // Substitua pelo número real no formato internacional
  const message = 'Olá! Gostaria de saber mais sobre seus serviços de design.';
  
  const handleClick = () => {
    const url = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  return (
    <button
      onClick={handleClick}
      className="fixed bottom-24 right-6 z-50 w-14 h-14 bg-lime-400 rounded-full flex items-center justify-center shadow-lg hover:bg-lime-300 transition-all hover:scale-110 group"
      aria-label="Contato via WhatsApp"
    >
      <MessageCircle className="text-black" size={28} />
      
      {/* Tooltip */}
      <span className="absolute right-full mr-3 px-3 py-2 bg-white text-black text-sm font-medium rounded-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap shadow-lg pointer-events-none">
        Fale no WhatsApp
      </span>
      
      {/* Pulse animation */}
      <span className="absolute inset-0 rounded-full bg-lime-400 animate-ping opacity-75" />
    </button>
  );
}